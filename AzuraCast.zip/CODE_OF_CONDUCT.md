# Code of Conduct

All repositories in the AzuraCast organization adhere to the Contributor Covenant code of conduct. We expect all
interactions across all media, including our GitHub issues and public social media channels, to adhere to these
guidelines.

Visit [the AzuraCast web site](https://www.azuracast.com/code_of_conduct.html) for the full text of our Code of Conduct.
