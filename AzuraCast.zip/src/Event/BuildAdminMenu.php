<?php
namespace App\Event;

class BuildAdminMenu extends AbstractBuildMenu
{}
