<?php
namespace App\Exception;

class Supervisor extends \Azura\Exception
{}
