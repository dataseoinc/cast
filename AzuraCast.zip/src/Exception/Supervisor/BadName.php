<?php
namespace App\Exception\Supervisor;

class BadName extends \App\Exception\Supervisor
{
}
