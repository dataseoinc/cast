<?php
namespace App\Http;

class ResponseHelper extends \Azura\Http\ResponseHelper
{
    /**
     * Empty placeholder class to hold possible future helper methods.
     */
}
